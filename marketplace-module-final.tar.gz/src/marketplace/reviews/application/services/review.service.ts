import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../../../shared/database/prisma.service';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class ReviewService {
  constructor(private readonly prisma: PrismaService) {}

  // Product Reviews
  async getProductReviews(productId: string, page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;

    const [reviews, total] = await Promise.all([
      this.prisma.review.findMany({
        where: {
          productId,
          entityType: 'PRODUCT',
        },
        include: {
          User: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              profileImage: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.review.count({
        where: {
          productId,
          entityType: 'PRODUCT',
        },
      }),
    ]);

    return {
      reviews: reviews.map((r) => ({
        id: r.id,
        rating: r.rating,
        comment: r.comment,
        images: r.images || [],
        createdAt: r.createdAt,
        user: {
          name: `${r.User.firstName} ${r.User.lastName}`,
          profileImage: r.User.profileImage,
        },
        helpfulCount: r.helpfulCount || 0,
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async addProductReview(
    userId: string,
    productId: string,
    rating: number,
    comment?: string,
    images?: string[],
  ) {
    // Verify product exists
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      throw new NotFoundException('Product not found');
    }

    // Check if user has purchased this product
    const hasPurchased = await this.prisma.orderItem.findFirst({
      where: {
        productId,
        Order: {
          userId,
          status: { in: ['DELIVERED', 'COMPLETED'] },
        },
      },
    });

    if (!hasPurchased) {
      throw new BadRequestException('You can only review products you have purchased');
    }

    // Check if user already reviewed this product
    const existingReview = await this.prisma.review.findFirst({
      where: {
        userId,
        productId,
        entityType: 'PRODUCT',
      },
    });

    if (existingReview) {
      throw new BadRequestException('You have already reviewed this product');
    }

    // Create review
    const review = await this.prisma.review.create({
      data: {
        id: uuidv4(),
        userId,
        productId,
        entityType: 'PRODUCT',
        rating,
        comment,
        images: images || [],
        updatedAt: new Date(),
      },
    });

    // Update product average rating
    const allReviews = await this.prisma.review.findMany({
      where: {
        productId,
        entityType: 'PRODUCT',
      },
      select: { rating: true },
    });

    const averageRating = allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;

    await this.prisma.product.update({
      where: { id: productId },
      data: {
        averageRating,
        reviewCount: allReviews.length,
        updatedAt: new Date(),
      },
    });

    return {
      id: review.id,
      rating: review.rating,
      comment: review.comment,
      createdAt: review.createdAt,
    };
  }

  async voteOnReview(userId: string, reviewId: string, helpful: boolean) {
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    });

    if (!review) {
      throw new NotFoundException('Review not found');
    }

    // Update helpful count (simplified - in production, track individual votes)
    const increment = helpful ? 1 : -1;

    await this.prisma.review.update({
      where: { id: reviewId },
      data: {
        helpfulCount: {
          increment,
        },
        updatedAt: new Date(),
      },
    });

    return {
      success: true,
      message: helpful ? 'Marked as helpful' : 'Marked as not helpful',
    };
  }

  // Store Reviews
  async getStoreReviews(storeId: string, page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;

    const [reviews, total] = await Promise.all([
      this.prisma.review.findMany({
        where: {
          storeId,
          entityType: 'STORE',
        },
        include: {
          User: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              profileImage: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.review.count({
        where: {
          storeId,
          entityType: 'STORE',
        },
      }),
    ]);

    return {
      reviews: reviews.map((r) => ({
        id: r.id,
        rating: r.rating,
        comment: r.comment,
        createdAt: r.createdAt,
        user: {
          name: `${r.User.firstName} ${r.User.lastName}`,
          profileImage: r.User.profileImage,
        },
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getStoreReviewSummary(storeId: string) {
    const reviews = await this.prisma.review.findMany({
      where: {
        storeId,
        entityType: 'STORE',
      },
      select: { rating: true },
    });

    if (reviews.length === 0) {
      return {
        averageRating: 0,
        totalReviews: 0,
        ratingDistribution: {
          5: 0,
          4: 0,
          3: 0,
          2: 0,
          1: 0,
        },
      };
    }

    const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;

    const ratingDistribution = reviews.reduce(
      (dist, r) => {
        dist[r.rating] = (dist[r.rating] || 0) + 1;
        return dist;
      },
      {} as Record<number, number>,
    );

    return {
      averageRating: Math.round(averageRating * 10) / 10,
      totalReviews: reviews.length,
      ratingDistribution: {
        5: ratingDistribution[5] || 0,
        4: ratingDistribution[4] || 0,
        3: ratingDistribution[3] || 0,
        2: ratingDistribution[2] || 0,
        1: ratingDistribution[1] || 0,
      },
    };
  }

  // Favorites
  async toggleFavorite(userId: string, productId: string) {
    const existing = await this.prisma.favorite.findUnique({
      where: {
        userId_productId: {
          userId,
          productId,
        },
      },
    });

    if (existing) {
      // Remove favorite
      await this.prisma.favorite.delete({
        where: {
          userId_productId: {
            userId,
            productId,
          },
        },
      });

      return {
        isFavorite: false,
        message: 'Removed from favorites',
      };
    } else {
      // Add favorite
      await this.prisma.favorite.create({
        data: {
          id: uuidv4(),
          userId,
          productId,
        },
      });

      return {
        isFavorite: true,
        message: 'Added to favorites',
      };
    }
  }

  async getFavorites(userId: string, page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;

    const [favorites, total] = await Promise.all([
      this.prisma.favorite.findMany({
        where: { userId },
        include: {
          Product: {
            include: {
              Store: {
                select: { id: true, name: true, imageUrl: true },
              },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.favorite.count({ where: { userId } }),
    ]);

    return {
      favorites: favorites.map((f) => ({
        id: f.id,
        product: {
          id: f.Product.id,
          name: f.Product.name,
          description: f.Product.description,
          price: f.Product.price,
          discountedPrice: f.Product.discountedPrice,
          imageUrl: f.Product.imageUrl,
          rating: f.Product.averageRating,
          reviewCount: f.Product.reviewCount,
          store: f.Product.Store,
        },
        addedAt: f.createdAt,
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  // Wishlist
  async toggleWishlist(userId: string, productId: string, note?: string) {
    const existing = await this.prisma.wishlist.findUnique({
      where: {
        userId_productId: {
          userId,
          productId,
        },
      },
    });

    if (existing) {
      // Remove from wishlist
      await this.prisma.wishlist.delete({
        where: {
          userId_productId: {
            userId,
            productId,
          },
        },
      });

      return {
        inWishlist: false,
        message: 'Removed from wishlist',
      };
    } else {
      // Add to wishlist
      await this.prisma.wishlist.create({
        data: {
          id: uuidv4(),
          userId,
          productId,
          note,
        },
      });

      return {
        inWishlist: true,
        message: 'Added to wishlist',
      };
    }
  }

  async getWishlist(userId: string, page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;

    const [wishlistItems, total] = await Promise.all([
      this.prisma.wishlist.findMany({
        where: { userId },
        include: {
          product: {
            include: {
              Store: {
                select: { id: true, name: true, imageUrl: true },
              },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.wishlist.count({ where: { userId } }),
    ]);

    return {
      wishlist: wishlistItems.map((w) => ({
        id: w.id,
        product: {
          id: w.product.id,
          name: w.product.name,
          description: w.product.description,
          price: w.product.price,
          discountedPrice: w.product.discountedPrice,
          imageUrl: w.product.imageUrl,
          rating: w.product.averageRating,
          store: w.product.Store,
        },
        note: w.note,
        addedAt: w.createdAt,
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }
}

